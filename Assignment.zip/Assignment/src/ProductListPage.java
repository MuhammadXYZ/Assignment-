import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ProductListPage {
    private List<WebElement> productElements;
    private List<ProductInfo> productsInfo;
    private WebDriver webDriver;

    public ProductListPage(WebDriver driver) {
        this.webDriver = driver;
    }

    public void getAllProducts(String productsClass, String productNameClass, String productPriceClass, String addToCartTagName) {
        try {
            productElements = webDriver.findElements(By.className(productsClass));
            productsInfo = new ArrayList<>();

            for (WebElement element : productElements) {
                String name = element.findElement(By.className(productNameClass)).getText();
                String price = element.findElement(By.className(productPriceClass)).getText();
                String addToCartId = element.findElement(By.tagName(addToCartTagName)).getAttribute("id");

                ProductInfo productInfo = new ProductInfo(name, price, addToCartId);
                productsInfo.add(productInfo);
            }
        } catch (Exception error) {
            error.printStackTrace();
        }
    }

    public int getRandomProductIndex() {
        return new Random().nextInt(productElements.size());
    }

    public ProductInfo getRandomProductInfo(int index) {
        if (index >= 0 && index < productsInfo.size()) {
            return productsInfo.get(index);
        }
        return null;
    }

    public class ProductInfo {
        private String name;
        private String price;
        private String addToCartId;

        public ProductInfo(String name, String price, String addToCartId) {
            this.name = name;
            this.price = price;
            this.addToCartId = addToCartId;
        }

        public String getName() {
            return name;
        }

        public String getPrice() {
            return price;
        }

        public String getAddToCartId() {
            return addToCartId;
        }
    }
}
