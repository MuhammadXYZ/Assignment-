import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
    private WebDriver webDriver;

    public LoginPage(WebDriver driver) {
        this.webDriver = driver;
    }

    public void navigateToUrl(String url) {
        try {
            webDriver.get(url);
        } catch (Exception error) {
            error.printStackTrace();
        }
    }

    public void enterText(String elementId, String text) {
        try {
            WebElement element = findElementById(elementId);
            element.sendKeys(text);
        } catch (Exception error) {
            error.printStackTrace();
        }
    }

    public void clickElement(String elementId) {
        try {
            WebElement element = findElementById(elementId);
            element.click();
        } catch (Exception error) {
            error.printStackTrace();
        }
    }

    public void login(String username, String password, String usernameTextBoxId, String passwordTextBoxId, String loginButtonId) {
        try {
            enterText(usernameTextBoxId, username);
            enterText(passwordTextBoxId, password);
            clickElement(loginButtonId);
        } catch (Exception error) {
            error.printStackTrace();
        }
    }

    public void verifyPageTitle(String xpathIdentifier, String expectedTitle) {
        try {
            WebElement titleElement = findElementByXPath(xpathIdentifier);
            String pageTitle = titleElement.getText();
            if (pageTitle.equals(expectedTitle)) {
                System.out.println("Title Verification Passed:\n" +
                        "Expected Title: " + expectedTitle + "\n" +
                        "Actual Title: " + pageTitle
                );
            } else {
                System.out.println("Title Verification Failed:\n" +
                        "Expected Title: " + expectedTitle + "\n" +
                        "Actual Title: " + pageTitle
                );
            }
        } catch (Exception error) {
            error.printStackTrace();
        }
    }

    private WebElement findElementById(String elementId) {
        try {
            return webDriver.findElement(By.id(elementId));
        } catch (Exception error) {
            error.printStackTrace();
            return null;
        }
    }

    private WebElement findElementByXPath(String xpathIdentifier) {
        try {
            return webDriver.findElement(By.xpath(xpathIdentifier));
        } catch (Exception error) {
            error.printStackTrace();
            return null;
        }
    }
}
