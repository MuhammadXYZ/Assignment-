import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ShoppingCartPage {
    private WebDriver webDriver;

    public ShoppingCartPage(WebDriver driver) {
        this.webDriver = driver;
    }

    public void clickElement(String elementId) {
        try {
            WebElement element = findElementById(elementId);
            element.click();
        } catch (Exception error) {
            error.printStackTrace();
        }
    }

    public void addToCart(String product) {
        try {
            clickElement(product);
        } catch (Exception error) {
            error.printStackTrace();
        }
    }

    public void checkout(String checkoutButtonId) {
        try {
            clickElement(checkoutButtonId);
        } catch (Exception error) {
            error.printStackTrace();
        }
    }

    public void navigateToCart(String elementId) {
        try {
            clickElement(elementId);
        } catch (Exception error) {
            error.printStackTrace();
        }
    }

    private WebElement findElementById(String elementId) {
        try {
            return webDriver.findElement(By.id(elementId));
        } catch (Exception error) {
            error.printStackTrace();
            return null;
        }
    }
}
